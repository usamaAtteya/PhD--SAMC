﻿Remember to run makeparser.bat to create the lex and yacc source

Note the variable "top" produced by GPPG is name clash undedr the new c# compiler and has been renamed to topIdx 
in the parser, so you need to run a find and replace on .top to .topIdx in the StepP21Parser.cs produced by GPPG