﻿namespace Xbim.Common.Step21
{
    public enum StepParserType
    {
        Boolean,
        Enum,
        Entity,
        HexaDecimal,
        Integer,
        Real,
        String,
        Undefined
    }
}
