﻿namespace Xbim.Common.Geometry
{
    public enum XbimDirectionEnum
    {
        WEST,
        EAST,
        NORTH,
        SOUTH,
        UP,
        DOWN
    }
}
