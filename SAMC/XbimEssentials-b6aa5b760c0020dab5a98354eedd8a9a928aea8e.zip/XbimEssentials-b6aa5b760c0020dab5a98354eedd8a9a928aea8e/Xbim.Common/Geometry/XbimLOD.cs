﻿namespace Xbim.Common.Geometry
{
    public enum XbimLOD
    {
        LOD_Unspecified,
        LOD100,
        LOD200,
        LOD300,
        LOD400,
        LOD500
    }
}
