﻿namespace Xbim.Common
{
    public delegate void ReportProgressDelegate(int percentProgress, object userState);
}
