namespace Xbim.Common
{
	public interface @IInstantiableEntity : IPersistEntity
	{
	}
}