﻿namespace Xbim.IO.TableStore
{
    public enum DataStatus
    {
        None,
        Optional,
        Required,
        Reference,
        PickValue,
        ExternalReference,
        Header,
        UserDefined
    }
}
