﻿namespace Xbim.IO
{
    public enum XbimGeometrySort
    {
        OrderByIfcSurfaceStyleThenIfcType,
        OrderByIfcTypeThenIfcProduct,
        OrderByGeometryID

    }
}
