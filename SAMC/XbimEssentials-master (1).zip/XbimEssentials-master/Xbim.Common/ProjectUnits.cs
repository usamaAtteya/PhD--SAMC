﻿namespace Xbim.Common
{
    /// <summary>
    /// Could do with Imperial :-)
    /// </summary>
    public enum ProjectUnits
    {
        SIUnitsUK
    }
}
