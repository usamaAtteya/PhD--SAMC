﻿namespace Xbim.Common.Step21
{
    public enum IfcSchemaVersion
    {
        Unsupported,
        Ifc4,
        Ifc2X3,
        Cobie2X4

    }
}
