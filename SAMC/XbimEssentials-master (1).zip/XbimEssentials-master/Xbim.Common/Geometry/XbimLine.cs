﻿namespace Xbim.Common.Geometry
{
    public class XbimLine
    {
        public XbimPoint3D Pnt { get; set; }
        public XbimVector3D Orientation { get; set; }
    }
}
